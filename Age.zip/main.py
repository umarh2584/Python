age=input("what is your age?")
print(age)